package exec

import "testing"

func TestExec(t *testing.T) {
}

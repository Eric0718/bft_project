package main

func main() {
	cli := &CLI{}
	cli.Run()
}
